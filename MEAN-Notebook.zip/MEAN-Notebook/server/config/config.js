
module.exports = {
    mongodb: {
        uri: 'mongodb://localhost:27017/notebook',
        options: {
            user: '',
            pass: ''
        },
        debug: true
    }
}