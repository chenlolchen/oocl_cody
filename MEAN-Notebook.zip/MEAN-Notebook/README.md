MEAN-Todo-App
=============

A Todo MEAN App - MongoDB, Expressjs, Angularjs and Nodejs

### Install

* Download/clone the repo
* Run `npm install`
* Run `gulp` and navigate to `http://localhost:3000` to view the app

### Tutorial 

[MEAN stack – A Hands on Tutorial](http://thejackalofjavascript.com/mean-stack-hands-on-tutorial)
